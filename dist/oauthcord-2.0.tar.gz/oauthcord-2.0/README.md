# OauthCord
### A discord Oauth2 wrapper for python.

## Install
To install OauthCord, run `python -m pip install oauthcord`.

## Support / Questions
For questions to do with the library's source or mistakes, please use the `issues` tab on the github source. ([here](https://github.com/lganWebb/oauthcord))
For questions to do with using the library please join the official OauthCord server [here](https://discord.gg/whdptKh)
